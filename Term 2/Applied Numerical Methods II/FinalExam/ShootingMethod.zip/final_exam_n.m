function dy=final_exam_n(x,y)
dy = [y(2); -y(2)*y(1);y(4);(-y(1)*y(4)) - (y(2)*y(3))];
end