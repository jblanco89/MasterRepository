clc; clear all;

% Cargar y configurar el modelo de Simulink
modelo = 'Laboratorio_grupal_v6'; % Nombre del modelo (sin extensión .slx)
load_system(modelo); % Cargar el modelo en MATLAB

%SIMULACIÓN T=8h
% Configurar parámetros de simulación si es necesario
set_param(modelo, 'StopTime', '8'); % Configurar tiempo de simulación (opcional)
% Dosis iniciales (en mg) transformadas a concentraciones (mg/L) considerando Vd = 42 L
% se establecen los volúmenes de distribución Vgut = 1L, V1 = 42 L
Vgut = 1;
V1 = 42;
Cgut_inicial = 200/Vgut; % Concentración inicial en Cgut (mg/L)
set_param([modelo '/Cgut_0'], 'Value', num2str(Cgut_inicial)); 
dosis = [400, 600, 1000] / V1;

Cmax = []; 
Tmax = []; 
AUC = [];  
Emax = []; 
T_Emax = []; 

figure('Position', [100, 100, 700, 800]);

% Para C1 (plasma)
subplot(2,1,1);
hold on;
title('Concentración Plasmática (C1) para diferentes concentraciones iniciales');
xlabel('Tiempo (h)');
ylabel('Concentración (mg/L)');
grid on;

% Para Ce (efectiva)
subplot(2,1,2);
hold on;
title('Concentración Efectiva (Ce) para diferentes concentraciones iniciales');
xlabel('Tiempo (h)');
ylabel('Concentración Efectiva');
grid on;

colors = {'r', 'g', 'b'};

for i = 1:length(dosis) % Para cada concentración inicial
    set_param([modelo '/C1_0'], 'Value', num2str(dosis(i))); 

    out = sim(modelo);

    C1 = out.C1; % Concentración plasmática
    Ce = out.Ce; % Concentración efectiva

    subplot(2,1,1);
    plot(C1.Time, C1.Data, 'Color', colors{i}, 'LineWidth', 1.5, 'DisplayName', ['Conc. Inicial: ', num2str(dosis(i)), ' mg/L']);

    subplot(2,1,2);
    plot(Ce.Time, Ce.Data, 'Color', colors{i}, 'LineWidth', 1.5, 'DisplayName', ['Conc. Inicial: ', num2str(dosis(i)), ' mg/L']);

    [max_C1, idx_Cmax] = max(C1.Data); % Cmax
    Cmax = [Cmax; max_C1];
    Tmax = [Tmax; C1.Time(idx_Cmax)];

    % Calcular el AUC 
    auc = trapz(C1.Time, C1.Data); % Integral numérica
    AUC = [AUC; auc];

    % Calcular métricas farmacodinámicas
    [max_Effect, idx_Emax] = max(Ce.Data); % Emax
    Emax = [Emax; max_Effect];
    T_Emax = [T_Emax; Ce.Time(idx_Emax)];
end

subplot(2,1,1);
legend('show');

subplot(2,1,2);
legend('show');

% Tabla de resultados
T = table(dosis', Cmax, Tmax, AUC, Emax, T_Emax, 'VariableNames', {'Conc. Inicial (mg/L)', 'Cmax (mg/L)', 'Tmax (h)', 'AUC', 'Emax', 'T_Emax (h)'});
disp(T);