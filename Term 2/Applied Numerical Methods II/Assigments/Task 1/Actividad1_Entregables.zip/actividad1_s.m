function dy = actividad1_s(x,y)
dy = [y(2);(2.*x.*y(1))-(y(2).*y(1))+2];
end