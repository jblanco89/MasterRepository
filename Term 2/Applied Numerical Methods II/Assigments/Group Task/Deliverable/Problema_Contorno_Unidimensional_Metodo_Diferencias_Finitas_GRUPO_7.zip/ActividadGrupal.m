% Actividad grupal...
clear;
clc;
format longg;
grid on;
hold on;

% parámetros...
f = @(x, y, z) -z.^2 + 4*y + 2;
fy = @(x, y, z) 4*ones(size(x)); % es necesario hacer esto para que genere un vector de 4s...
fz = @(x, y, z) -2*z;
a = 1;
b = 2;
alfa = 0;
beta = 3;
n = 100; % número de subintervalos...
tol = 1e-5;
maxiter = 50;
ulti = 10; % mostrar los últimos nodos...
repe = 100; % veces que se repite el algoritmo para estimar el tiempo de ejecución...

% solución para el algoritmo de Crout...
texe = zeros(1,repe);

for t = 1:repe
    [X, Y, iterc, texec] = DiffinNLND(f, fy, fz, a, b, alfa, beta, n, tol, maxiter, 'Crout');
    texe(t) = texec;
end

% presentación para el algoritmo de Crout...
Xc = X(end-ulti+1:end);
Yc = Y(end-ulti+1:end);
texec = mean(texe);
tablac1 = table(Xc, Yc, 'VariableNames', {'x', 'y(x) (Crout)'});
tablac2 = table(iterc, texec, 'VariableNames', {'iteraciones', 'tiempo medio ejecución (s)'});
disp(['Resultados con el algoritmo de Crout...' newline])
disp(tablac1)
disp(tablac2)
plot(X, Y, '.-');

% solución para el método de Gauss...
for t = 1:repe
    [X, Y, iterg, texeg] = DiffinNLND(f, fy, fz, a, b, alfa, beta, n, tol, maxiter, 'Gauss');
    texe(t) = texeg;
end

% presentación para el método de Gauss...
Xg = X(end-ulti+1:end);
Yg = Y(end-ulti+1:end);
texeg = mean(texe);
tablag1 = table(Xg, Yg, 'VariableNames', {'x', 'y(x) (Gauss)'});
tablag2 = table(iterg, texeg, 'VariableNames', {'iteraciones', 'tiempo medio ejecución (s)'});
disp(['Resultados con el algoritmo de Gauss...' newline])
disp(tablag1)
disp(tablag2)
plot(X, Y, 'o-');

legend('Crout', 'Gauss');
title('Problema de contorno no lineal no Dirichlet');
xlabel('x');
ylabel('\approx y(x)');

% comparativa de tiempos medios de ejecución...
gc = texeg/texec;
fprintf('La relación de tiempos medios de ejecución entre Gauss y Crout es %f,\nluego Gauss es %f veces más lento que Crout.\n\n', gc, gc)

% comparativa de resultados...
disp(table(Xc, Yc, Yg, abs(Yc - Yg), 'VariableNames', {'x', 'yc(x) (Crout)', 'yg(x) (Gauss)', '| yc(x) - yg(x) |'}))