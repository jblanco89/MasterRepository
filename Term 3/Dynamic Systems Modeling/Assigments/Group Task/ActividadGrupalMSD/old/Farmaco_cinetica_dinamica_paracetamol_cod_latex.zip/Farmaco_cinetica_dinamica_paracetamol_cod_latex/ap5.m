clc; clear all;
modelo = 'Laboratorio_grupal_v6';
load_system(modelo);

%SIMULACIÓN T=8h
% Configurar parámetros de simulación si es necesario
set_param(modelo, 'StopTime', '8'); % Configurar tiempo de simulación (opcional)
% se establecen los volúmenes de distribución Vgut = 1L, V1 = 42 L
Vgut = 1;
V1 = 42;
% se reconfiguran los parámetros de la simulución para ese Vd...
dosis_cgut = 200/Vgut;
dosis_c1 = 1000/V1;
set_param([modelo '/Cgut_0'], 'Value', num2str(dosis_cgut)); 
set_param([modelo '/C1_0'], 'Value', num2str(dosis_c1)); 

% Distintos valores de Ka
gain_values = [0.80 1.0 1.2 1.8 2.2 2.6];

% Gráficos
% figure;
figure('Position', [100, 100, 700, 700]);

% Para Cgut (Concentración gastrointestinal)
subplot(2,1,1);
hold on;
title('Concentración en el Intestino (Cgut) para diferentes valores de Ka');
xlabel('Tiempo (h)');
ylabel('Concentración');
grid on;

% Para C1 (Concentración en el compartimento 1 o compartimento plasmático)
subplot(2,1,2);
hold on;
title('Concentración en Compartimento 1 (C1) para diferentes valores de Ka');
xlabel('Tiempo (h)');
ylabel('Concentración');
grid on;

% Colores para cada línea
colors = {'k', 'b', 'r', 'g', 'm', 'k'};

for i = 1:length(gain_values)
    set_param([modelo '/Ka'], 'Gain', num2str(gain_values(i)));

    out = sim(modelo);
    
    % Extraemos datos del workspace
    Cgut = out.Cgut;
    C1 = out.C1;
    
    % Graficar Cgut y C1 vs Tiempo
    subplot(2,1,1);
    plot(Cgut.Time, Cgut.Data, 'Color', colors{i}, 'LineWidth', 1.1);
    
    subplot(2,1,2);
    plot(C1.Time, C1.Data, 'Color', colors{i}, 'LineWidth', 1.1);
end

% Leyendas
subplot(2,1,1);
legend(cellstr(num2str(gain_values', 'Ka = %.1f')));

subplot(2,1,2);
legend(cellstr(num2str(gain_values', 'Ka = %.1f')));

% Restablecer el valor original de Ka
set_param([modelo '/Ka'], 'Gain', '1.8');