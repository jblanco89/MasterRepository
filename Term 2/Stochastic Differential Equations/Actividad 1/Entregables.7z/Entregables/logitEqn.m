function dX = logitEqn(t, X)
a = 1;
b = 1;
dX = a.*(b-X);
end