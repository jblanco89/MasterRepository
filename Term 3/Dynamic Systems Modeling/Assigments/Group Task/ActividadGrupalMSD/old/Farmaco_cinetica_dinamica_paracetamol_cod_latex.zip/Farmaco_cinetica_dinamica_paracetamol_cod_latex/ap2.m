clc; clear all;

% Cargar y configurar el modelo de Simulink
modelo = 'Laboratorio_grupal_v6'; % Nombre del modelo (sin extensión .slx)
load_system(modelo); % Cargar el modelo en MATLAB

%SIMULACIÓN T=8h
% Configurar parámetros de simulación si es necesario
set_param(modelo, 'StopTime', '8'); % Configurar tiempo de simulación (opcional)
% se establecen los volúmenes de distribución Vgut = 1L, V1 = 42 L
Vgut = 1;
V1 = 42;
% se reconfiguran los parámetros de la simulución para ese Vd...
dosis_cgut = 200/Vgut;
dosis_c1 = 1000/V1;
set_param([modelo '/Cgut_0'], 'Value', num2str(dosis_cgut)); 
set_param([modelo '/C1_0'], 'Value', num2str(dosis_c1)); 

% Ejecutar la simulación
out = sim(modelo);

%Extracción de variables
Cgut = out.Cgut; % Valores de Cgut
C1 = out.C1; % Valores de C1
C2 = out.C2; % Valores de C2
Ce = out.Ce; % Valores de Ce
effect=out.effect;

%Plots
% Crear los subplots
figure;

% Subplot 1: Concentración en el intestino (Cgut)
subplot(4,1,1);
plot(Cgut.Time, Cgut.Data, 'LineWidth', 1.5);
title('Concentración en el Intestino (Cgut)');
xlabel('Tiempo (h)');
ylabel('Concentración');
grid on;

% Subplot 2: Concentración en el compartimento 1 (C1)
subplot(4,1,2);
plot(C1.Time, C1.Data, 'LineWidth', 1.5);
title('Concentración en el Compartimento 1 (C1)');
xlabel('Tiempo (h)');
ylabel('Concentración');
grid on;

% Subplot 3: Concentración en el compartimento 2 (C2)
subplot(4,1,3);
plot(C2.Time, C2.Data, 'LineWidth', 1.5);
title('Concentración en el Compartimento 2 (C2)');
xlabel('Tiempo (h)');
ylabel('Concentración');
grid on;

% Subplot 4: Concentración en el efecto (Ce)
subplot(4,1,4);
plot(Ce.Time, Ce.Data, 'LineWidth', 1.5);
title('Concentración en el Efecto (Ce)');
xlabel('Tiempo (h)');
ylabel('Concentración');
grid on;

%CALCULO DE EFECTO MAXIMO
%Plots
figure;

plot(effect.Time, effect.Data, 'LineWidth', 1.5);
title('Efecto del fármaco (Effect)');
xlabel('Tiempo (h)');
ylabel('Efecto');
grid on;