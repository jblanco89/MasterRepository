clc; clear all;
modelo = 'Laboratorio_grupal_final';
load_system(modelo);

%SIMULACIÓN T=8h
% Configurar parámetros de simulación si es necesario
set_param(modelo, 'StopTime', '8'); % Configurar tiempo de simulación (opcional)
% se establecen los volúmenes de distribución Vgut = 1L, Vd = 42 L
Vgut = 1;
Vd = 42;
F = 0.89;
% se reconfiguran los parámetros de la simulución...
dosis_cgut = 200*F/Vgut;
dosis_c1 = 1000/Vd;
set_param([modelo '/Cgut_0'], 'Value', num2str(dosis_cgut)); 
set_param([modelo '/C1_0'], 'Value', num2str(dosis_c1)); 

% valores de K
Kval = [0, 0.28, 1, 3, 5];

l = length(Kval);

figure;
hold on;
title('Efecto del fármaco (Effect)');
xlabel('Tiempo (h)');
ylabel('Efecto');
grid on;

for i = 1:l
    set_param([modelo '/K'], 'Gain', num2str(Kval(i)));

    out = sim(modelo);

    % se extraen los datos del workspace
    effect = out.effect;

    if Kval(i) == 0.28
        plot(effect.Time, effect.Data, '-', 'Color', 'r', 'LineWidth', 1.1);
    else
        plot(effect.Time, effect.Data, 'LineWidth', 1.1);
    end
end

legend(cellstr(num2str(Kval', 'K = %.2f')));

% se restablece el valor original de K
set_param([modelo '/K'], 'Gain', '0.28');