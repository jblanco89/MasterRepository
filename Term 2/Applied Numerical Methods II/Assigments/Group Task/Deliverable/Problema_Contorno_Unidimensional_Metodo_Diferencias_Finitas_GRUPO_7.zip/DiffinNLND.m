function [X, Y, iter, texe] = DiffinNLND(f, fy, fz, a, b, alfa, beta, n, tol, maxiter, metodo)
    % Resuelve problema de contorno de segundo orden no lineal con condiciones no Dirichlet.
    %
    % Parámetros:
    %   f : y'' (derivada segunda de la función incógnita y)
    %   fy : derivada parcial de f respecto de y
    %   fz : derivada parcial de f respecto de y' (z = y')
    %   a, b : extremos del intervalo [a, b]
    %   alfa, beta : términos independientes de las condiciones de contorno
    %   n : número de subintervalos
    %   maxiter : número máximo de iteraciones
    %   tol : tolerancia
    %   metodo : método de resolución de la ecuacion no lineal: 'Crout', 'Gauss'
    %
    % Retorno:
    %   X : vector columna de nodos
    %   Y : vector columna de soluciones de y para cada nodo
    %   iter : última iteración
    %   texe : tiempo de ejecución
    tic;

    h = (b - a)/n;
    hy = (beta - alfa)/n;
    X = a:h:b;
    Y = alfa:hy:beta; % solución inicial para el método de Newton...
    x = X(1:n+1);
    y = Y(1:n+1);
    iter = 1;
    incre = tol + 1;

    while incre > tol && iter < maxiter
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % personalizo con las condiciones de contorno...
        z0 = (alfa - Y(1))/2;
        zn = (Y(end) + beta)/2;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        z = [z0, (Y(3:end) - Y(1:end-2))/(2*h), zn];
        F = feval(f, x, y, z);
        Fy = feval(fy, x, y, z);
        Fz = feval(fz, x, y, z);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % personalizo con las condiciones de contorno...
        g0 = (2 - h)*y(1) - 2*y(2) + alfa*h + h^2*F(1);
        gn = (2 - h)*y(end) - 2*y(end-1) - beta*h + h^2*F(end);
        g00 = 2 - h + h^2*Fy(1) - h^2/2*Fz(1);
        g01 = -2;
        gnn1 = -2;
        gnn = 2 - h + h^2*Fy(end) + h^2/2*Fz(end);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        dP = [g00, 2 + h^2*Fy(2:end-1), gnn];
        dS = [g01, -1 + h/2*Fz(2:end-1)];
        dI = [-1 - h/2*Fz(2:end-1), gnn1];
        G = [g0, -y(3:end) + 2*y(2:end-1) - y(1:end-2) + h^2*F(2:end-1), gn];

        switch metodo
            case 'Crout'
                w = Crout(dP, dS, dI, G);
            case 'Gauss'
                dG = diag(dP, 0) + diag(dS, 1) + diag(dI, -1);
                w = dG\G';
            otherwise
                error('Error: método no disponible');
        end

        y = y - w';
        Y = y;
        incre = norm(w);
        %incre = max(abs(w)); % otro criterio de convergencia...
        iter = iter + 1;
    end

    if incre > tol
        disp('Aviso: Se necesitan más iteraciones.')
    end

    X = X(:);
    Y = Y(:);
    texe = toc;
end